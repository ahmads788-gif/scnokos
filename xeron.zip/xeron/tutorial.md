📱 Setup Bot KyzzOfficial

1. 🔑 Ambil API Key KhafaTopup

1. Daftar di khafatopup.my.id
2. Chat @UCOK109 minta akses H2H
3. Login → klik titik tiga → API Key
4. Salin API Key

2. 🔐 Ambil API Key RumahOTP

1. Daftar di rumahotp.com
2. Deposit minimal Rp 2.000
3. Profil → API Settings → Generate
4. Salin API Key

3. 🤖 Buat Bot Telegram

1. Cari @BotFather di Telegram
2. Ketik /newbot
3. Kasih nama: KyzzOfficial Bot
4. Kasih username: kyzzofficial_bot
5. Salin Token yang diberikan

4. 👑 Ambil User ID

1. Cari @userinfobot di Telegram
2. Ketik /start
3. Catat ID Anda (contoh: 123456789)

5. 📢 Buat Channel

1. Di Telegram, buat New Channel
2. Nama: Kyzz Official
3. Username: @kyzzofficial
4. Undang bot sebagai Admin

6. ⚙️ Edit config.js

Buka file settings/config.js:

```javascript
module.exports = {
    // Telegram Bot
    bot_token: "TOKEN_DARI_BOTFATHER",
    
    // API Keys
    apikey: "API_KEY_RUMAHOTP",
    khafa_apikey: "API_KEY_KHAFATOPUP",
    
    // Owner Settings
    owner_ids: ["ID_ANDA"],  // Contoh: ["123456789"]
    username_owner: "@username_anda",
    
    // Channel
    channel: "@kyzzofficial",
    
    // Domain
    domain: "https://rumahotp.com",
    
    // Biaya
    fee_settings: 300,
    fee_deposout: 0,
    fee_nokos: 0,
    fee_product: 1000
}
```

7. ▶️ Jalankan Bot

📌 Catatan Penting:

· Jangan bagikan API Key ke siapapun
· Simpan backup config.js
· Test deposit kecil dulu
· Bot harus admin di channel 
