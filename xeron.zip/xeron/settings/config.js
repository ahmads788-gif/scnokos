module.exports = {
  bot_token: 'token_bot',
  owner_ids: ['id_owner'],
  channel: '@username_ch',
  username_owner: '@username_lu',
  domain: 'https://www.rumahotp.com/api',
  apikey: 'apikey_rumahotp',
  khafa_apikey: 'apikey_khafa',
  fee_product: 200,
  fee_nokos: 250,
  fee_deposout: 450
};